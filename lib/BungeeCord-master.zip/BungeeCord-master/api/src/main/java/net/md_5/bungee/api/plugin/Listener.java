package net.md_5.bungee.api.plugin;

/**
 * Dummy interface which all event subscribers and listeners must implement.
 */
public interface Listener
{
}
